module.exports = {
  priorityAreas: require('./priorityAreasController'),
  fundingSources: require('./fundingSourcesController'),
  users: require('./usersController'),
  opportunities: require('./opportunitiesController'),
  dashboard: require('./dashboardController'),
  applications: require('./applicationsController')
};